title: 解决微信小程序 chooselocation在ios下不能稳定触发的问题
date: '2018-10-02 23:19:48'
updated: '2018-10-02 23:19:48'
tags: [Note]
permalink: /articles/2018/10/02/1567739699109.html
---
如果你能看到这个问题，肯定能明白我在说什么。直接上解决办法

```js
 setTimeout(() => {
      this.moveToLocation() // chooseLocation的包装函数
    }, 150)
```

在页面onLoad生命周期里 用150ms的延迟来保证触发。具体原因未知，官方文档没有写，很明显是微信的坑。具体多少延迟你可以尝试找到最佳值。