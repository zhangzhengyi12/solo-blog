title: Property 'id' has no initializer and is not definitely assigned in the constructor.
  在Vue中使用TS提示prop参数没有被初始化和定义 解决办法
date: '2018-03-26 05:37:24'
updated: '2018-03-26 05:37:24'
tags: [error, typescript, vue]
permalink: /articles/2018/03/26/1567739714518.html
---
我的工程是用Vue-cli 的3.0版本初始化的，添加了TS，后来一直会爆整个错误，简单的解决就是 在@prop() 声明的时候，添加一个！，比如

`  @Prop() id !: number `

他的含义就是不对这个变量进行检查，但是不安全，也会让编辑器认为错误，后来在github的issue中找到了解决办法

> 打开你的tsconfig.json文件
> 并加入如下选项
> "strictPropertyInitialization": false,

这样就会让TS不过分严格的检查传进来的prop