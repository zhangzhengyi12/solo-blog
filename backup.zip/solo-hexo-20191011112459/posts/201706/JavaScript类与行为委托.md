title: JavaScript 类与行为委托
date: '2017-06-14 03:18:12'
updated: '2017-06-14 03:18:12'
tags: [JavaScript, 继承, 设计模式]
permalink: /articles/2017/06/14/1567739690783.html
---
最近在写了几个WEB常用组件只有开始重新读《你所不知道的javaScript》。并且收获良多，之前只是理解原理。但是并没有深切的体会到其中的意义。现在已经有过一些组件的经验，所以更加能理解到这种对象关联方式的优势。


# 面对对象 #

类在其他的OO语言中都是一个最为核心的概念。在JS中可以中可以通过借用的方式实现类似其他语言中的继承。但会增加代码的复杂度和可读性。

下面是面对对象的代码

    function Foo(who) {
		this.me = who;
	}

	Foo.prototype.identify = function() {
	return "I am " + this.me;
	};
	function Bar(who) {
		Foo.call( this, who );
	}
	Bar.prototype = Object.create( Foo.prototype );
	Bar.prototype.speak = function() {
	alert( "Hello, " + this.identify() + "." );
	};
	var b1 = new Bar( "b1" );
	var b2 = new Bar( "b2" );
	b1.speak();
	b2.speak();


在Bar的构造函数中call Foo的构造函数 并用原型来继承Foo的原型对象 。


# 对象关联 #

	Foo = {
		init: function(who) {
		this.me = who;
		},
		identify: function() {
		return "I am " + this.me;
		}
	};
	Bar = Object.create( Foo );
	Bar.speak = function() {
	alert( "Hello, " + this.identify() + "." );
	};
	var b1 = Object.create( Bar );
	b1.init( "b1" );
	var b2 = Object.create( Bar );
	b2.init( "b2" );
	b1.speak();
	b2.speak();

直接使用原型链来关联两个对象，减少了代码量，但是其功能完全一致。而且整体的结构更加的清晰。不需要想复杂的依赖关系，只需要建立简单的对象关联。如果在子类中也可以很方便的委托父类。