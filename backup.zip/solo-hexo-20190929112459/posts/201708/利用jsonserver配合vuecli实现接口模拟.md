title: 利用json-server配合vue-cli实现接口模拟
date: '2017-08-13 05:25:30'
updated: '2017-08-13 05:25:30'
tags: [Vue, json, 接口]
permalink: /articles/2017/08/13/1567739707620.html
---
json-server是一个用来模拟http请求的工具，我们可以通过他来方便优雅的做到接口测试。

请注意我的环境是vue-cli

# 第一步安装 #

 ` npm i josn-server --save-dev`

 # 第二步 配置 # 

 打开 ` XXproject > build > dev-server.js `

 找到 ` app.use(staticPath, express.static('./static') ` 这一行 也就是express的静态资源设置， 在其下方加入如下代码

 ```js

const jsonServer = require('json-server')
const apiServer = jsonServer.create()
const router = jsonServer.router('db.json')
const middlewares = jsonServer.defaults()

apiServer.use(middlewares)
apiServer.use(router)
apiServer.listen(8081, () => {
  console.log('JSON Server is running')
})


 ```

 # 第三步 增加模拟数据 #

 在整个工程的根目录，也就是和模版index平级的目录，增加一个db.json文件，以下是我的文件

 ```js

 //db.josn

{
        "getNewsList":[
            {"url":"yinode.tech","title":"神鬼传说销量破万"},
            {"url":"yinode.tech","title":"竞技场正在开发"},
            {"url":"yinode.tech","title":"服务器出现登录困难正在修复"},
            {"url":"yinode.tech","title":"庆中秋，感恩大回馈"}
        ],
        "getBorderList":[
            "hello"
        ]
}

 ```

 这时当你开启 dev的时候应该就能一起开启json-server了 比如说` ("http://localhost:8081/getNewsList")`

 整个服务现在已经能个跑起来了,但这还不够方便优雅，能不能把前面的localhost去掉呢？答案当然是可以的，我们可以通过代理来做到。


# 第四步 设置代理 #

打开 ` build > config > index.js `

在dev对象中添加如下属性
`  proxyTable: {
      '/api/':'http://localhost:8081/'
    },
`

这样每当你访问localhost:xxx/api的时候，就会帮你导向至8081端口，但是还没有完成。
因为你既然添加了一个地址为api，当josn-server接受到的时候他发现并没有/api/这个东西，下面的数据自然也无法取到了，所以你需要手动为json-server添加一级路由

打开之前的dev-server.js

修改属性如下

```js

apiServer.use('/api',router)


```

这样一来，所有的向api/的下级目录的请求都会被json-server所接收了,就好比是api变成了数据的根目录

最后的请求方式

```js

this.$http.get("api/getNewsList")

```