title: React上手：一个聊天机器人聚合应用
date: '2017-12-25 07:56:08'
updated: '2017-12-25 07:56:08'
tags: [React, Redux, Robot, 项目实践]
permalink: /articles/2017/12/25/1567739708009.html
---
## 预览 ##

![](https://ws1.sinaimg.cn/large/0061RWEngy1fn9q2bv1spj30rd075q3i.jpg)
![](https://ws1.sinaimg.cn/large/0061RWEngy1fn9q2d2dt9j3280123woi.jpg)

界面UI方面模仿了TIM

## 技术栈 ##

主要使用了以下工具

- React 主体视图框架
- Redux 数据管理
- superAgent Ajax请求
- axios 后台反向代理（有些机器人没CROS）
- react-custom-scrollbar 滚动组件

## 实现 ##

实现了以下的功能
- 集合了四个机器人
- 机器人的切换
- 聊天记录的本地缓存与手动清除
- 聊天记录的自动滚动以及手动滚动
- 聊天气泡能够正常显示img和link
- 用户ID的登入与登出
- 用户ID的表单验证
- 大体上做了响应式设计

## 杂项 ##

这个项目算是我的React练手工具吧，算是完全重写了我之前的一个demo。大约从初学React到写完大约用了五天时间。其实我觉得只要有MVVM的框架的经验基础，学习一个新的框架也是比较快的，因为他们好的地方都很相似，比如数据绑定，虚拟DOM，插槽机制。

来说一下他们的差异化吧

1. JSX语法，和vue的类似HTML的有很大差异。
2. 强调一种从上而下的数据流，比如他推荐你只从根app组件中从redux获取数据，并把这些数据进行分发，他不推荐把数据和逻辑过多的放置到子组件中，这可能会造成更多的耦合。
3. 事件处理的方式不同，React更多是把自己的回调传递给子组件，子组件监听之后去调用父组件定义的回调。
4. 强调无副作用，Redux强制你进行无副作用的数据更新这一点我非常喜欢。
5. 数据绑定的方式不一样，Vue使用ES5的getter,setter进行更新，但是react不一样，他必须使用setState才能让相应的视图监听触发，从而刷新视图。

总得来说，我认为Vue比较OO React可能偏函数化。

## Code ##

[预览](http://yinode.tech/line-robot/)
[Code](https://github.com/zhangzhengyi12/line-robot)