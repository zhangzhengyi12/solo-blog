title: 图灵机器人WEB版
date: '2017-08-02 00:30:14'
updated: '2017-08-02 00:30:14'
tags: [图灵机器人]
permalink: /articles/2017/08/02/1567739687947.html
---
# 展示 #

![](https://ws1.sinaimg.cn/large/0061RWEngy1fn9qoxktiyj30km0llmxf.jpg)

# 技巧 #

对于一条消息记录让他往上走是我通过遍历之前的消息让bottom多加一定的数达到的，每次新消息的bottom都是恒定的50px,以此来模仿消息向上顶的效果。

随机的颜色是通过一个十六进制生成算法来做到的非常简单。

	function getRamdomColor() {
		    var result = '#';
		    for (var i = 0; i < 6; i++) {
	
		        result += Math.floor(Math.random() * 16).toString(16); //获取0-15并通过toString转16进制
		    }
	
		    return result;
		}


# 地址 #

预览


[http://yinode.tech/RobotInWeb/](http://yinode.tech/RobotInWeb/)


源码

[https://github.com/zhangzhengyi12/RobotInWeb](https://github.com/zhangzhengyi12/RobotInWeb)