title: 我在 GitHub 上的开源项目
date: '2019-09-07 11:14:57'
updated: '2019-09-07 11:14:57'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [vue-scrollbars](https://github.com/zhangzhengyi12/vue-scrollbars) <kbd title="主要编程语言">Vue</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/zhangzhengyi12/vue-scrollbars/watchers "关注数")&nbsp;&nbsp;[⭐️`10`](https://github.com/zhangzhengyi12/vue-scrollbars/stargazers "收藏数")&nbsp;&nbsp;[🖖`4`](https://github.com/zhangzhengyi12/vue-scrollbars/network/members "分叉数")</span>

基于 Vue 的 PC端滚动组件 避免原生滚动条的样式差异 



---

### 2. [quick-movie](https://github.com/zhangzhengyi12/quick-movie) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/zhangzhengyi12/quick-movie/watchers "关注数")&nbsp;&nbsp;[⭐️`9`](https://github.com/zhangzhengyi12/quick-movie/stargazers "收藏数")&nbsp;&nbsp;[🖖`4`](https://github.com/zhangzhengyi12/quick-movie/network/members "分叉数")</span>

使用React开发的快速观影APP其中资源部分利用爬虫，即将和正在上映部分采用豆瓣公共API



---

### 3. [quick-cli](https://github.com/zhangzhengyi12/quick-cli) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/zhangzhengyi12/quick-cli/watchers "关注数")&nbsp;&nbsp;[⭐️`7`](https://github.com/zhangzhengyi12/quick-cli/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zhangzhengyi12/quick-cli/network/members "分叉数")</span>

quick-cli是一个适用于静态，多页，小团队的中小型前端项目开发的脚手架工具。express + gulp + stylus + fileInclude



---

### 4. [dada-book](https://github.com/zhangzhengyi12/dada-book) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/zhangzhengyi12/dada-book/watchers "关注数")&nbsp;&nbsp;[⭐️`4`](https://github.com/zhangzhengyi12/dada-book/stargazers "收藏数")&nbsp;&nbsp;[🖖`2`](https://github.com/zhangzhengyi12/dada-book/network/members "分叉数")</span>

ReactNative开发的达达看书app 主要基于安卓端



---

### 5. [zhangzhengyi12.github.io](https://github.com/zhangzhengyi12/zhangzhengyi12.github.io) <kbd title="主要编程语言">TypeScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zhangzhengyi12/zhangzhengyi12.github.io/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/zhangzhengyi12/zhangzhengyi12.github.io/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zhangzhengyi12/zhangzhengyi12.github.io/network/members "分叉数")</span>





---

### 6. [netease-cloud-muisc](https://github.com/zhangzhengyi12/netease-cloud-muisc) <kbd title="主要编程语言">Vue</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/zhangzhengyi12/netease-cloud-muisc/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/zhangzhengyi12/netease-cloud-muisc/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zhangzhengyi12/netease-cloud-muisc/network/members "分叉数")</span>

a pc web music player, using Vue + Vue-Router  + Vuex + Vue-resource + TypeScript



---

### 7. [vue-moblie-music-app](https://github.com/zhangzhengyi12/vue-moblie-music-app) <kbd title="主要编程语言">Vue</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/zhangzhengyi12/vue-moblie-music-app/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/zhangzhengyi12/vue-moblie-music-app/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zhangzhengyi12/vue-moblie-music-app/network/members "分叉数")</span>

一个基于vue的移动端音乐播放器



---

### 8. [RobotInWeb](https://github.com/zhangzhengyi12/RobotInWeb) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/zhangzhengyi12/RobotInWeb/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/zhangzhengyi12/RobotInWeb/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zhangzhengyi12/RobotInWeb/network/members "分叉数")</span>

网页版的图灵机器人



---

### 9. [solo-blog](https://github.com/zhangzhengyi12/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zhangzhengyi12/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zhangzhengyi12/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zhangzhengyi12/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://blog.yinode.tech`](https://blog.yinode.tech "项目主页")</span>

Yinde's  Blog - Talk is cheap. Show me the code.



---

### 10. [lucky-package-cli](https://github.com/zhangzhengyi12/lucky-package-cli) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/zhangzhengyi12/lucky-package-cli/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zhangzhengyi12/lucky-package-cli/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zhangzhengyi12/lucky-package-cli/network/members "分叉数")</span>

NPM 组件库脚手架

