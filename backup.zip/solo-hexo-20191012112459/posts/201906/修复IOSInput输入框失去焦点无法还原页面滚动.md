title: 修复 IOS Input 输入框失去焦点无法还原页面滚动
date: '2019-06-13 19:15:28'
updated: '2019-06-13 19:15:28'
tags: [Bug, IOS, input]
permalink: /articles/2019/06/13/1567739688277.html
---
推荐注册到 Vue 全局 Mixin 里 并在 updated 生命周期中重新运行

```js
const fixInputPaddingMixin = {
  mounted() {
    this._fixInput();
  },
  updated() {
    this._fixInput();
  },
  methods: {
    _fixInput() {
      let inputs = document.querySelectorAll('input');
      if (inputs.length >= 1) {
        for (let item of inputs) {
          item.addEventListener(
            'focus',
            () => {
              item.scrollTop = document.body.scrollTop;
            },
            false,
          );
          item.addEventListener(
            'blur',
            () => {
              document.body.scrollTop = item.scrollTop || 0;
            },
            false,
          );
        }
      }
    },
  },
};
```