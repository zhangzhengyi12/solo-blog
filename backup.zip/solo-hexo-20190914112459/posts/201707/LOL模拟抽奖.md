title: LOL模拟抽奖
date: '2017-07-30 07:08:48'
updated: '2017-07-30 07:08:48'
tags: [lol, 项目实践]
permalink: /articles/2017/07/30/1567739708398.html
---
最近试着写了一个LOL模拟抽奖的页面，大家可以随便玩玩，也没任何广告。

删除了一小部分失效的英雄，皮肤部分没动。

所有英雄皮肤的几率都是正好平分的。

地址[https://yinode.tech/lolSimDraw/](https://yinode.tech/lolSimDraw/ "无极剑圣的斩星魔剑")

如果转发的话请注明一下出处，谢谢！