title: 利用express实现数据接口模拟
date: '2017-08-13 06:43:51'
updated: '2017-08-13 06:43:51'
tags: [express, json]
permalink: /articles/2017/08/13/1567739709620.html
---
之前我介绍了利用json-server创建数据模拟接口的方法，但这个方法实质上是有缺陷的，因为json-server不能很好的处理post请求，所以我又寻找到了一种直接利用express和插件创建接口的方法

依旧是vue-cli搭建的环境。

首先在服务器启动脚本也就是是dev-server.js里面找到 `app.use(staticPath, express.static('./static'))`

在后面添加如下内容

```js

// express API

var apiServer = express()
var bodyParser = require('body-parser')
apiServer.use(bodyParser.urlencoded({ extended: true }))
apiServer.use(bodyParser.json())
var apiRouter = express.Router()
var fs = require('fs')
apiRouter.route('/:apiName')
.all(function (req, res) {
  fs.readFile('./db.json', 'utf8', function (err, data) {
    if (err) throw err
    var data = JSON.parse(data)
    if (data[req.params.apiName]) {
      res.json(data[req.params.apiName])  
    }
    else {
      res.send('no such api name')
    }

  })
})


apiServer.use('/api', apiRouter);
apiServer.listen(port + 1, function (err) {
  if (err) {
    console.log(err)
    return
  }
  console.log('Listening at http://localhost:' + (port + 1) + '\n')
})

//express API

```

这种方式我认为在表达力上是很强的，你可以清除看到在监听到请求之后他做了什么事情，

当然不要忘了在index.js中添加代理，让普通端口下对api的访问代理到api端口

```js

dev:{
	//some
	proxyTable: {
	      '/api/':'http://localhost:8081/'
	    },
}

```


还有就是对于db文件的创建

 ```js

 //db.josn

{
        "getNewsList":[
            {"url":"yinode.tech","title":"神鬼传说销量破万"},
            {"url":"yinode.tech","title":"竞技场正在开发"},
            {"url":"yinode.tech","title":"服务器出现登录困难正在修复"},
            {"url":"yinode.tech","title":"庆中秋，感恩大回馈"}
        ],
        "getBorderList":[
            "hello"
        ]
}

 ```