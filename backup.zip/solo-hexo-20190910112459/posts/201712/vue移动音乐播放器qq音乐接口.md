title: vue移动音乐播放器（qq音乐接口）
date: '2017-12-16 07:57:23'
updated: '2017-12-16 07:57:23'
tags: [player, vue, 播放器, 项目实践]
permalink: /articles/2017/12/16/1567739696472.html
---
## 预览 ##

![](https://ws1.sinaimg.cn/large/0061RWEngy1fn9qiv4zruj30if0vx48p.jpg)
![](https://ws1.sinaimg.cn/large/0061RWEngy1fn9qiyrrd4j30hx0vdqby.jpg)

## 技术栈 ##

使用VUE的全家桶，并且使用了以下主要组件

- axios 代理后端接口
- better-scroll 主要的滚动组件
- creat-keyframe-animation 在JS中创建关键帧动画
- vue-lazyload 图片懒加载
- jsonp 主要的jsonp接口包装


## 感想 ##

### 目录结构 ###
首先创建一个优秀的目录结构绝对是非常重要的事情，这将很好的帮助你寻找和管理你的文件。

贴上我的目录结构

```

├─api // 接口包装
├─base // 基本组件
│  ├─alert
│  ├─confirm
│  ├─listview
│  ├─loading
│  ├─no-result
│  ├─progress-bar
│  ├─progress-circle
│  ├─scroll
│  ├─search-box
│  ├─search-list
│  ├─song-list
│  ├─switches
│  └─top-tip
├─common // 通用内容
│  ├─fonts
│  ├─image
│  ├─js
│  └─stylus
├─components // 大型组件
│  ├─add-song
│  ├─disc
│  ├─m-header
│  ├─music-list
│  ├─player
│  ├─playlist
│  ├─rank
│  ├─recommend
│  ├─search
│  ├─singer
│  ├─singer-detail
│  ├─suggest
│  ├─tab
│  ├─toplist
│  └─user-center
├─router // vue-router
└─store // vuex

```

### vuex的正确使用方式 ##

把一个vuex对象进行分离是极为推荐的选择，本质上就是把一个vuex模块封装进了很多文件，然后在组件中用展开符的方式来引入这些actions getter 等等。之后就能通过this.actionName的方式调用，非常的好，不会让整个vuex的代码过于厚重集中。

```
  actions.js
    getters.js
    index.js
    mutation-type.js
    mutations.js
    state.js
    store.js
```

### mixins ###

mixins是vue提供的一种抽象方法，他能提取出一些组件的共同点，并通过mixins的方式混入到组建之中，减少重复的代码，合理使用他可以带来一些好处，但另外一方面，我认为也略微降低了组件的可读性。

### slot ###


slot用来传递大量的DOM结构和渲染逻辑非常合适，远比props来的轻松。用好他可以让封装出来的组件更好用。

### 接口 ###

接口基本来源于qq音乐的PC版web页面，大部分都是jsonp的请求，少量接口有referer鉴权，可以通过后端代理的方式来获取到。

### 小心渲染顺序 ###

我认为这是非常容易出错的地方，这关系到v-show和v-if的渲染特性。要小心他们的渲染时间，这很容易导致一些关于时间的BUG，比如里面的DOM结构无法被另外的组件成功初始化。

简单来讲，v-show在组件渲染时一起渲染，开启与关闭只是简单的css切换，而v-if则是会重建DOM节点。 v-show更适合频繁切换的场景，v-if则是适合在一些不太频繁开关的元素上使用。**但两者的数据都是会被持续运作的**。

很多时候都会出这样的错，监听数据更改 > 数据为true则用v-if开启某个节点 接着刷新某个夫组件的初始化程序 。但是发现无法正常初始化， 原因就是从数据更改带真正DOM节点的建立需要时间。而触发某个初始化的速度太快了。解决的办法就是settimeout。

**Vue的动画也会导致DOM的更新变慢**

## 不足 ##

我到最后也没能解决最新版本Chrome for android 的play方法无法触发的问题，就算是利用toustart来触发也不行，这源于chrome的一种安全机制。但是绝大部分的浏览器通过HACK的方式都是能够正常播放的。


## 总结 ##

Vue是一个数据驱动的MVVM框架，他很好的体现了他的初衷，轻量 迅速 。他的生态链目前发展的也非常的好，有很多的组件可以去调用，甚至能用weex来写安卓ios的app。也很好的保留的类似HTML的模板语法，上手迅速，威力很大/

[Preview](http://yinode.tech/vue-moblie-music-app)
[CODE](https://github.com/zhangzhengyi12/vue-moblie-music-app)