title: 利用gh-pages展示自己的DEMO
date: '2017-06-15 05:15:58'
updated: '2017-06-15 05:15:58'
tags: [Github, demo, pages]
permalink: /articles/2017/06/15/1567739687435.html
---
之前一直都是用的git-demo-preview来展示预览自己做的DEMO和工程，但是有很多不足

 - 会加载很多无关的JS
 - 访问速度不够理想

所以最近记录一下使用gh-pages来展示自己的分支。

# 开始 #

如果在你的pages主页面即username.github.io创建了一个静态博客。占用之后就没有地方展示你的DEMO了。而gh-pages就是为了解决这个问题。


## 第一步 推送 ##

首先你需要把需要展示的静态文件推送到gh-pages分支（假设dist目录存放用于展示的静态文件）

	git branch gh-pages

	git checkout gh-pages

    git subtree push --prefix=dist origin gh-pages

	//他的含义是把dist目录推送到远程的gh-pages分支

## 第二步 设置 ##

 接着把github仓库中 `setting > GitHub Pages > Source` 打开设置为`gh-pages`


## 第三步 预览 ##
最后就可以使用username.github.io/rponame来访问你的DEMO预览了。

比如
[http://yinode.tech/require-sidebar/](http://yinode.tech/require-sidebar/)


要注意的是README.md的展示优先级是高于index.html的,这意味是你可能需要删除静态展示目录下的README.MD.