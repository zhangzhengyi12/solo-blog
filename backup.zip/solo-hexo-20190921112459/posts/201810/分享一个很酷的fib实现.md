title: 分享一个很酷的fib实现
date: '2018-10-04 09:24:50'
updated: '2018-10-04 09:24:50'
tags: [fib]
permalink: /articles/2018/10/04/1567739706446.html
---
```js
const fib = n =>
  Array(n)
    .fill(0)
    .reduce(pre => [pre[1], pre[1] + pre[0]], [0, 1])[0]
```

```python
def fib(n): return reduce(lambda x, n: [x[1], x[0]+x[1]], range(n), [0, 1])[0]
```

性能也非常不错，迭代实现。从 Py 那边偷学的。
帅爆了有没有