title: Hexo Blog 升级全家桶 Https + Pwa + VPS构建
date: '2018-01-09 05:57:19'
updated: '2018-01-09 05:57:19'
tags: [hexo]
permalink: /articles/2018/01/09/1567739721613.html
---
今天升级了一下博客，主要是特别试用最新的PWA，可以让webapp固定在移动端的桌面，并且提供稳定可靠的缓存服务，没网也能跑。

PS: 后续把PWA和HTTPS全给关了。主要原因是我博客和我一些demo都在同一个域名下，都用https之后有些普通的http请求都不让我发了，所有那些DEMO全炸了，唉，还是恢复吧。。。。。。

## HTTPS ##

首先是博客添加一个https加密，因为PWA必需标配https，但我的博客是在gh-pages上的，并没有https功能，所以就要依赖
` cloudflare `这家提供商，他的https其实也是伪https，完全就是半路加密，不过能让我们跑PWA就可以了。

基本就是登陆上去设置解析，然后找到SSL开成智能就OK，一般需要几小时的证书颁发时间。也可以开启http自动跳转到s


## PWA ##

先安装一下插件

` cnpm i hexo-pwa --save `

接着在主hexo配置文件里加入如下内容

```js

pwa:
  manifest:
    path: /manifest.json
  serviceWorker:
    path: /sw.js
    preload:
      urls:
        - /
      posts: 10
    opts:
      networkTimeoutSeconds: 5
    routes:
      - pattern: !!js/regexp /hm.baidu.com/
        strategy: networkOnly
      - pattern: !!js/regexp /.*\.(js|css|jpeg|png|gif)$/
        strategy: cacheFirst
      - pattern: !!js/regexp /\//
        strategy: networkFirst
  priority: 5

```

接下我们需要一个清单文件，我就直接贴上我自己的了


```js
// mainfest.json source目录
{
  "name": "LaoLiuBlog",
  "short_name": "Blog",
  "theme_color": "#545557",
  "background_color": "#ecf1f5",
  "display": "fullscreen",
  "Scope": "/",
  "start_url": "/",
  "icons": [
    {
      "src": "images/icons/icon-72x72.png",
      "sizes": "72x72",
      "type": "image/png"
    },
    {
      "src": "images/icons/icon-96x96.png",
      "sizes": "96x96",
      "type": "image/png"
    },
    {
      "src": "images/icons/icon-128x128.png",
      "sizes": "128x128",
      "type": "image/png"
    },
    {
      "src": "images/icons/icon-144x144.png",
      "sizes": "144x144",
      "type": "image/png"
    },
    {
      "src": "images/icons/icon-152x152.png",
      "sizes": "152x152",
      "type": "image/png"
    },
    {
      "src": "images/icons/icon-192x192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "images/icons/icon-384x384.png",
      "sizes": "384x384",
      "type": "image/png"
    },
    {
      "src": "images/icons/icon-512x512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ],
  "splash_pages": null
}

```

然后hexo clean + g + d一下 基本就能用了

注意如果你用了http的cdn（非s），那就换个cdn或者图床,因为pwa不支持http的。会爆一大堆的错误。切记切记！。


## 远程构建 ##

其实随着文档的变多，自己也爱用高亮代码，后果就是构建时间将尽一分钟，太慢啦，等不起!

不过我们可以通过一些服务帮我们持续构建，比如Travis


1.首先我们需要登陆Travis,接着同步我们的博客仓库，我的仓库是Master为展示分支，source为源码分支，

![](https://ws1.sinaimg.cn/large/0061RWEngy1fn9ldu16wwj30jg05r0sn.jpg)
开启这两项


2.让我们去创建一个token来给travis操作我们仓库的权限。具体可以搜索一下github创建token


3.接着把我们的token存入trivel的设置之中，其中的name之后会用到，*注意这个名字不要用奇怪的字符，会失败失败*

![](https://ws1.sinaimg.cn/large/0061RWEngy1fn9lhdgzd1j30jg03bmwy.jpg)

4.最后一步就在hexo的源目录里创建一个` .travis.yml ` 文件
并填入如下内容，已经标注了需要注意的点



```yml
language: node_js
node_js: stable

# S: Build Lifecycle
install:
  - npm install


before_script:
 - git clone  "https://${auto}@${THEME_RP}" themes/next # 克隆一下主题
 - npm i
 - cd themes/next
 - npm i
 - cd ../../
 - git config user.name "zhangzhengyi12"
 - git config user.email "zhangzhengyi12@live.com"

script:
  - hexo g

after_script:
  - cd ./public
  - git init
  - git add *
  - git commit -m "Update docs"
  - git push --force --quiet "https://${auto}@${GH_REF}" master:master ## 在tokenName里填入你的token名字
# E: Build LifeCycle

branches:
  only:
    - source #源分支，只有处在这个分支下的变更才会触发构建
env:
 global:
   - GH_REF: github.com/zhangzhengyi12/zhangzhengyi12.github.io.git  # 你的http仓库地址
   - THEME_RP: github.com/zhangzhengyi12/hexo-theme-next.git # 主题地址，我为了方便放自己的配置文件 fork的一份官方

```

如果你没有用主题可以不用clone主题直接生成，但如果你用了雀没克隆会造层出来的html都是空白的，我为了方便克隆和覆盖主题配置文件就自己fork了一份官方的，随后修改了下配置文件。


到这里应该已经可以很舒服的继续用HEXO了。