title: Node实现图灵机器人
date: '2017-07-31 03:59:00'
updated: '2017-07-31 03:59:00'
tags: [图灵机器人, 项目实践]
permalink: /articles/2017/07/31/1567739722180.html
---
# 展示 #

![](https://ws1.sinaimg.cn/large/0061RWEngy1fn9qpjr6luj30yx0dwgng.jpg)


# 技巧 #

颜色方面采用了ANSI Color

## 注册成全局 ##

在package下添加如下字段

	"scripts": {
	    "start": "node ./bin/chat.js",
	    "test": "echo \"Error: no test specified\" && exit 1"
	  },
	  "bin": {
	    "robot": "./bin/chat.js"
	  },

start即代表在工程目录下输入npm start就用 node启动chat.js

bin表示命令行输入robot就运行chat.js 但是你得在chat.js下第一行输入如下命令来告诉系统调用 node执行

    #!/usr/bin/env node
	let chat = require('../index.js');

	chat();

之后使用 `npm i -g` 命令 把这个bin链接到系统目录，类似全局安装，之后就可以在任意目录调用


# 地址 #

源码

[https://github.com/zhangzhengyi12/robot](https://github.com/zhangzhengyi12/robot)