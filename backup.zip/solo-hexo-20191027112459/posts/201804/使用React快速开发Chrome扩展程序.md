title: 使用React快速开发Chrome扩展程序
date: '2018-04-29 07:40:56'
updated: '2018-04-29 07:40:56'
tags: [chrome扩展, react]
permalink: /articles/2018/04/29/1567739706085.html
---
首先要说明的是这个文章其实属于翻译或者说转述，我是从google上搜索到了这篇原文，并且用它的构建流程成功开发了一个扩展，很爽，速度很快，五分钟直接进入扩展开发，不需要花费太多的精力在构建开发环境上，不过可能还会有一些不太方便的方，下面会讲到。 我们开始吧！

## 全局安装 create-react-app

>  npm install –g create-react-app

## 构建你的应用程序

请随意命名
> create-react-app reactextension

## 修改mainfest文件

进入你的开发目录，public/mainfest.json是你扩展的主要入口，删除他的所有内容，写入如下内容

chrome扩展将会依赖这个文件加载页面

```json
{
  "short_name": "React App",
  "name": "React Extension",
  "manifest_version": 2,
  "browser_action": {
    "default_popup": "index.html",
    "default_title": "React Ext"
  },
  "version": "1.0"
}
```

接下来你需要运行一次 ` yarn build ` 来初次打包，你的程序将会输出到**dist**文件内

## 加载你的扩展程序

打开你的Chrome扩展中心`  chrome://extensions  `，请确保**勾选开发者模式**，**拖入**你的**dist**文件夹

OK! 恭喜你，你的应用程序应该已经成功的加载到了chrome扩展列表中，快去尝试打开它吧！如果你想要进一步的修改图标名称等，请修改mainfest文件，图标图片放置在public目录中，这里要谈到一点可惜之处，就是` yarn dev `模式下并不能加载这个扩展，我个人推荐你在dev模式下以一个普通网页的方式去dubug一部分，待到累积一定功能的时候，再去build一下看看效果。


最后 来推荐一下我开发的扩展（已经是第三次重写了，前两次都没用框架，复用性确实比较差）

![](https://yinodimage.oss-cn-hangzhou.aliyuncs.com/18-4-28/91676507.jpg)
![](https://yinodimage.oss-cn-hangzhou.aliyuncs.com/18-4-29/95096649.jpg)

完全开源，你完全可以clone下来自行编译改进，从功能上讲，他的主要目的就是帮我排雷，评分特别低的片就不需要去看了，同时爬了某电影资源网站的信息，可以进行快速的下载，你完全可以通过他来快速的查看最近有没有值得看的爽片!


[DaDa Movie for github](https://github.com/zhangzhengyi12/quick-movie)
[@Mackenzie Higa](https://engineering.musefind.com/how-to-build-a-chrome-extension-with-react-js-e2bae31747fc)

最后，感谢你们的阅读! 有兴趣可以来我的博客看看[blog](yinode.tech)