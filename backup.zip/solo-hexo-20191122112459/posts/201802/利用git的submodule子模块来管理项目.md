title: 利用git的submodule(子模块) 来管理项目
date: '2018-02-13 09:03:29'
updated: '2018-02-13 09:03:29'
tags: [git]
permalink: /articles/2018/02/13/1567739700229.html
---
我相信很多人都有过在一个项目中引入一个乃至多个库的经历，但是如果我们的主项目使用git来进行版本控制并且使用单纯的add&commit就会导致我们的项目与库产生了一种不太好的耦合关系，我们更希望我们的项目和库可以分离出来。他们相互独立存在，并可以单独提交，有着不同的diff，status信息。

所以git提供了解决方案 - **submodule**

## submodule ##

>submodule允许你将一个 Git 仓库当作另外一个Git仓库的子目录。这允许你克隆另外一个仓库到你的项目中并且保持你的提交相对独立。

## 添加一个submodule ##

现在假设我们拥有一个项目名为 ` my-pro ` 他拥有一个模块文件夹，我们希望能把一个名为 ` my-api-server `的库增加到modules文件夹之中。


我们其实只需要一条命令

>git submodule add https://github.com/zhangzhengyi12/my-api-server.git ./modules/api`

这条命令就是添加模子模块的基本命令,他会帮你克隆这个仓库并添加为一个模块.


接下来让我们来看看到底发生了什么事，输入 ` git status ` 来查看一下更改。



```js
        new file:   .gitmodules
        new file:   modules/api
```

我们会发现生成了一个` .gitmodules `文件

这个文件的主要内容其实就是模块的声明和关联,如果你有多个子模块，这个文件里会有多个条目。
当然这个文件也需要你进行一次提交，才能被加入到版本控制库之中。当别人克隆你的主项目时，git将依赖这个文件来管理子模块。

```
[submodule "modules/api"]
	path = modules/api
	url = https://github.com/zhangzhengyi12/my-api-server.git
```

事实上从现在开始，你就拥有了两个不相关的git仓库，你可以切换到` modules/api `目录下进行push pull commit 任何操作都不会和主项目产生关联，在主项目下进行git命令同样如此。

也就是说如果我们需要更新某个子模块，只需要切换到子模块的目录并pull一下就可以更新了，但是如果出现合并之后头指针并没有更新的问题，你需要 ` git submodule update ` 来解决这个问题。

## clone这个完整的项目 ##

那么如何来clone一个包含子模块的项目呢？

一般来说有两种方式:

### 1 采用递归参数 ###

```
 git clone https://github.com/zhangzhengyi12/project.git --recursive
```

这种方式会自动帮你克隆主项目以及相应的子模块

### 2 三步走 ###


1. ` git clone https://github.com/zhangzhengyi12/my-pro.git  `
2. ` git submodule init `
3. ` git submodule update `