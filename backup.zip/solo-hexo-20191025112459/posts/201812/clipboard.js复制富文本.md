title: clipboard.js 复制富文本
date: '2018-12-01 18:53:14'
updated: '2018-12-01 18:53:14'
tags: [clipboard.js]
permalink: /articles/2018/12/01/1567739703595.html
---
小技巧

```js
new clipboard('.copyart', {
  text: function(trigger) {
    return $editor.getContent()
  }
})
document.addEventListener('copy', function(e) {
  e.clipboardData.setData('text/html', e.target.value)
  e.preventDefault()
})
```