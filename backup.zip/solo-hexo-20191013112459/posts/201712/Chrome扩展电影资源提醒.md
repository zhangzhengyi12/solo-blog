title: Chrome扩展：电影资源提醒
date: '2017-12-30 08:36:47'
updated: '2017-12-30 08:36:47'
tags: [Chrome, extensions, 项目实践]
permalink: /articles/2017/12/30/1567739721849.html
---
## 预览 ##
![](https://ws1.sinaimg.cn/large/0061RWEngy1fn9q26rnz4j30mh0y11kx.jpg)

其实这个插件很早以前就完成了，但是实现的逻辑完全不一样，直接AJAX获取然后插入到插件页面中，问题就在最近Chrome版本一升级炸了，和源页面的GB2312的编码有关。

最后干脆直接在我的服务器上写个小爬虫吧，每隔半小时就自动爬下数据然后格式化进我的数据库。并提供一个JSON的接口。在服务器上用cheerio来进行解析比在前端用正则匹配还是方便多了。

[接口地址](http://api.laoliuscript.tk/api/getNewMovie)

随后在扩展这边创建DOM插入就可以了。其实Chrome扩展的上手难度非常低，但是还是非常有用的，至少这个扩展能为我节省一些时间，看看最近有没有新资源很方便。

## 功能 ##

主要有以下的功能

- 本地存储电影数据（自动更新）
- 手动从服务器抓取
- 自动提醒是否有新资源

对于爱看电影的朋友可能有帮助，并没有写太多的功能。

## CODE ##

[github](https://github.com/zhangzhengyi12/66ys-movie-notice)

最后，由于穷上传不起chrome商店。本地加载凑合也能用