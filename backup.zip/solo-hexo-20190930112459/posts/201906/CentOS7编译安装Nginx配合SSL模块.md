title: CentOS 7 编译安装 Nginx 配合 SSL 模块
date: '2019-06-20 06:15:04'
updated: '2019-06-20 06:15:04'
tags: [nginx, ssl]
permalink: /articles/2019/06/20/1567739721086.html
---
## 准备

先安装一下接下来需要的依赖套件

> yum install -y gcc-c++ openssl openssl-devel zlib zlib-devel pcre pcre-devel

## 下载 nginx

> cd ~
> wget http://nginx.org/download/nginx-1.12.2.tar.gz
> tar -zxvf nginx-1.12.2.tar.gz

## 编译安装

> cd nginx-1.12.2
> ./configure --prefix=/usr/local/nginx --with-http_ssl_module
> make && make install

检测安装是否成功

> /usr/local/nginx/sbin/nginx -v

## 常用操作

> /usr/local/nginx/sbin/nginx # 启动
> /usr/local/nginx/sbin/nginx -s reload # 重启
> /usr/local/nginx/sbin/nginx -s stop # 停止
> /usr/local/nginx/sbin/nginx -s quit # 退出

## 简单配置

增加自动导入功能，方便区分服务器上的各个子服务

> vim /usr/local/nginx/conf/nginx.conf

在 server 上面加入一行

>   include /usr/local/nginx/conf/vhost.d/*.conf; # 自动导入该目录下的所有配置
>   server {


下面给出一个导入的 conf 文件示例


```
# /usr/local/nginx/conf/vhost.d/blog.conf
server{
    server_name api.yinode.tech;
    listen 80;
    location / {
        # proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header Host $http_host;
        proxy_set_header X-NginX-Proxy true;
        proxy_pass http://127.0.0.1:9527$request_uri;
        proxy_redirect off;
    }
}
server{
    server_name api.yinode.tech;
    listen 443 ssl;
    ssl_certificate     /usr/local/nginx/conf/vhost.d/blog.auth/cer.crt;
    ssl_certificate_key /usr/local/nginx/conf/vhost.d/blog.auth/pri.key;
    location / {
        # proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header Host $http_host;
        proxy_set_header X-NginX-Proxy true;
        proxy_pass http://127.0.0.1:9527$request_uri;
        proxy_redirect off;
    }
}
```

重启服务

> /usr/local/nginx/sbin/nginx -s reload # 重启

## 开启 gzip

性能增强

> vim vim /usr/local/nginx/conf/nginx.conf

加入如下内容，位置与上面的导入配置同级,应该默认是注释掉的，取消注释即可

>  gzip on;

重启服务

> /usr/local/nginx/sbin/nginx -s reload # 重启