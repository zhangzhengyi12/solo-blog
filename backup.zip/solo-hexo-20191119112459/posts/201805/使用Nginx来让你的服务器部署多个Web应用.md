title: 使用Nginx来让你的服务器部署多个Web应用
date: '2018-05-17 23:53:49'
updated: '2018-05-17 23:53:49'
tags: [linux, nginx, node, php]
permalink: /articles/2018/05/17/1567739699293.html
---
最近捣鼓了不少时间，起初想到要弄这个就是因为 node 直接起 server 的方式有点暴力，因为占用了 80 端口就是真的占用了，很难在用一个 80 端口挂多个 WebServer。你只能挂载在多个端口上，访问起来后面还得加个端口，太丑了，所以摸索了一下，用 Nginx 配置了一个多服务结构。这样就能通过不同的子域名来访问不同的应用了！

> 大致的结构

![](https://yinodimage.oss-cn-hangzhou.aliyuncs.com/18-5-18/95590032.jpg)

本质上就是 nginx 负责转发进来的请求，那么转发的依据就是判断不同的子域名

## STEP 1 Install Nginx

第一步当然是安装 nginx，各个平台不太一样，也没法分享了。我自己的 ubuntu 的环境

> apt-get isntall nginx

## STEP 2 Set DNS AND PORT

去你的域名管理商那里分配你想要的子域名，当然都是 A 记录并全部解析到你的 VPS 公网 IP 上.

另外一个准备就是修改你所有的 NodeWebServer 的端口，可以按你的爱好设置，但是不要占用 80 以及 443 端口

## STEP 3 nginx config Node.js

切换到你的**nginx 配置目录**

我的目录位置

> /etc/nginx/

这里要说明 nginx 是拥有 Include 机制的，他会自动加载 conf.d 目录下的所有 _.conf_（默认配置下） ，所以我们并不需要修改 nginx.conf 文件。我们接下来需要在 conf.d 目录下创建一系列的配置文件，文件名请使用你相应的工程名，比如 **project1.conf**

如果没有请手动加入

```nginx
        include /etc/nginx/conf.d/*.conf;
        # include /etc/nginx/sites-enabled/*; // 最好给他注释了 默认页面没啥用
```

开始编写项目配置

> cd conf.d

> touch project1.conf

> vim project1.conf

让我们编写详细的转发规则

```nginx
// 这是一个NODE Web Server
// 我已经将这个服务的端口改成了8000端口
// 当nginx捕获到访问域名为api.yinode.tech的时候
// 就会转发到本地的8000端口
server{
    server_name api.yinode.tech;
    listen 80;
    location / {
        # proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header Host $http_host;
        proxy_set_header X-NginX-Proxy true;
        proxy_pass http://127.0.0.1:8000$request_uri;
        proxy_redirect off;
    }
}
```

如果你需要转发 HTTPS，请复制一份上面的内容粘贴到下面，修改监听端口为 443，转发端口就是你监听的 https 端口！

## STEP 4 nginx config PHP

php 的转发设置会稍有一些不同，（默认你已经安装好了 PHP）

```nginx
server {
  listen 80;
  root /var/www/longqiyoutian/wordpress; // 你的根目录
  index index.php;
  server_name dragon.yinode.tech;
  error_page 404 /404.html;
  location ~ \.php$ {
    try_files $uri = 404;
    fastcgi_pass unix:/var/run/php/php7.0-fpm.sock; // 你的fpm地址
    fastcgi_index index.php;
    include fastcgi_params;
    fastcgi_param  SCRIPT_FILENAME  $document_root$fastcgi_script_name; // 必须填写，注意顺序
  }
}
```

逐个讲解，首先我们的 Root 目录会变的重要，Nginx 将会把这个目录转发给 FPM 来跑 PHP 代码，所以不要写错了，第二是后面的转发必须加上 `fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;`这能引导 fpm 进行正确的地址拼接

> TIPS:提醒

nginx 和 FPM 的默认启动用户都是 www-data,所以你的网站根目录请务必修改所属者为 www-data,并且不要将这个目录放置到/root/ 下，会出现权限问题，最好复制到/var/www 目录下，并设置所属者！

## STEP 5 Repeat

重复 3 4 步骤，创建所有你需要的项目配置

## STEP 6 Restart nginx

> service nginx restart

如果出现报错，仔细查看信息，去网上找，一般都是因为配置文件格式错误。

## STEP 7 Run

打开你的网站吧，应该可以正常运行了！以后新增 Server 其实也只要增加一个对应的 conf 文件，非常的方便，并且整个网站访问起来非常美观！

## 后续更新

在后续我迁移服务器的时候出现了了一些问题 在此发出我的解决办法 如果你们也有相同问题，希望能帮到你们

## 在转发请求到本地NODE.js服务端的时候出现502Bad Gateway

我的解决办法是 proxy_pass http://127.0.0.1:8000$request_uri;
删除后面的$request_uri

## HTTPS无法正常启用

我的选择是让nginx进行HTTPS处理 放弃用Node.js处理https请求

在`/etc/nginx/`下创建crt目录 放置你的公钥私钥

```nginx
server{
    server_name api.yinode.tech;
    ssl on;
    ssl_certificate crt/api.yinode.tech.crt;
    ssl_certificate_key crt/api.yinode.tech.key;
    ssl_session_timeout 5m;
    ssl_protocols SSLv2 SSLv3 TLSv1;
    ssl_ciphers ALL:!ADH:!EXPORT56:RC4+RSA:+HIGH:+MEDIUM:+LOW:+SSLv2:+EXP;
    ssl_prefer_server_ciphers on;
    listen 443 ;
    location / {
        # proxy_http_version 1.1;
        proxy_set_header Connection ""; 
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header Host $http_host;
        proxy_set_header X-NginX-Proxy true;
        proxy_pass http://127.0.0.1:8000;
        proxy_redirect off;
    }
}
```