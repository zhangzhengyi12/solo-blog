title: 使用jQuery实现轮播图切换和选项卡效果
date: '2017-05-25 06:49:26'
updated: '2017-05-25 06:49:26'
tags: [demo, jQuery]
permalink: /articles/2017/05/25/1567739701746.html
---
最近在学习jQuery，使用jQuery实现了一些常见的效果
## 1.图片轮播图和选项卡 ##

DEMO地址如下
[http://htmlpreview.github.io/?https://github.com/zhangzhengyi12/demo-repository/blob/master/JQueryAdvTab/index.html](http://htmlpreview.github.io/?https://github.com/zhangzhengyi12/demo-repository/blob/master/JQueryAdvTab/index.html "DEMO地址")

### 调用方式 ###
    <div class="js-tab tab" data-config='{
        "triggerType":"mouseover",
        "effect":"default",
        "invoke":1,
        "auto":3000
        }' style="float: right;margin-right: 30px">
            <p style="color: #fff;font-size: 12px;">自动轮播 无动画效果 鼠标移动触发</p>
            <ul class="tab-nav">
                <li class="actived"><a href="javascript:void(0)">新闻</a></li>
                <li><a href="javascript:void(0)">娱乐</a></li>
                <li><a href="javascript:void(0)">电影</a></li>
                <li><a href="javascript:void(0)">科技</a></li>
            </ul>
            <div class="content-wrap">
                <div class="content-item current "><img src="img/a.jpg" height="200" width="290"></div>
                <div class="content-item"><img src="img/b.jpg"  height="200" width="290"></div>
                <div class="content-item"><img src="img/c.jpg"  height="200" width="290"></div>
                <div class="content-item"><img src="img/d.png"  height="200" width="290"></div>
            </div>
        </div>

触发

    $(function () {
                $(".js-tab").tab();
            })

### 大体思路 ###

利用整个轮播模块的父元素div的data-来承载其设置选项（字符串JSON形式）

通过接收到的JSON对象来进行一次与默认属性之间的覆盖（jq的extend方法用来覆盖属性非常好用）

为对象增加切换方法，所有的切换都通过这个方法来间接达到，通过检测属性来绑定悬停切换或者点击切换，

自动播放通过延时调用来做到

最后注册为jQuery的方法，添加链式调用

### 要注意的地方 ###

在闭包外部注意将this赋值给_this_ 方便闭包内部访问

内部的自动播放是通过trigger事件来做到的要注意事件冒泡

公用的方法应放置在原型对象中方便重用

## 2.下拉加载 ##

利用了下拉事件检测高度 然后动态的显示模块
[http://htmlpreview.github.io/?https://github.com/zhangzhengyi12/demo-repository/blob/master/JQueryLoadDemo/index.html](http://htmlpreview.github.io/?https://github.com/zhangzhengyi12/demo-repository/blob/master/JQueryLoadDemo/index.html "下拉加载")


## 3.图片预加载技术 ##

将图片的真实地址放置到data上 然后每当页面滚动就检测图片是否在窗口之中，如果为真就将本来指向1px的src替换为真实地址。图片使用一张loading的gif图 等图片加载完毕会自动覆盖gif
[http://htmlpreview.github.io/?https://github.com/zhangzhengyi12/demo-repository/blob/master/jQueryLoadImg/index.html](http://htmlpreview.github.io/?https://github.com/zhangzhengyi12/demo-repository/blob/master/jQueryLoadImg/index.html "图片预加载")