title: URLSearchParams的兼容性问题
date: '2018-06-29 06:12:35'
updated: '2018-06-29 06:12:35'
tags: [Note]
permalink: /articles/2018/06/29/1567739704710.html
---
最近在用这个URLSearchParams，发现在Edge以及部分版本的IOS微信浏览器内部是不存在的，存在兼容性问题，所以解决办法就是使用polyfill

适配了各种各样的调用方式



[url-search-params-polyfill](https://github.com/jerrybendy/url-search-params-polyfill/)