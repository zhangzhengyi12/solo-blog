title: vue
date: '2018-08-07 19:23:28'
updated: '2018-08-07 19:23:28'
tags: [textarea, vue-lazyload]
permalink: /articles/2018/08/07/1567739712202.html
---
## vue-lazyload 图片无法动态更新

> 加上一个 Key 属性即可

```html
  <img @click.stop="clickAvatarHandle" v-lazy="getAvatar()" alt="" :key="getAvatar()" ref="avatar">
```

## 隐藏文本域的拖拽

> resize 属性

```css
resize: none;
```

## 更改文本域的光标颜色

```css
caret-color: #666;
```