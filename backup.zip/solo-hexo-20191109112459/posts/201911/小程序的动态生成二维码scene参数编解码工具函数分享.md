title: 小程序的动态生成二维码 scene 参数编解码工具函数分享
date: '2019-11-08 14:52:07'
updated: '2019-11-08 14:52:07'
tags: [小程序]
permalink: /articles/2019/11/08/1573195926968.html
---
适用于小程序动态生成二维码的时候，scene 参数的诸多限制，可以避免 HTTP query 参数本身的干扰和微信的限制，能够存放 KV 对

> scene 最大32个可见字符，只支持数字，大小写英文以及部分特殊字符：`!#$&'()*+,/:;=?@-._~`，其它字符请自行编码为合法字符（因不支持`%`，中文无法使用 `urlencode` 处理，请使用其他编码方式）

```
const encodeScene = obj => {
  let keys = Object.keys(obj)

  let res = []

  for (let key of keys) {
    res.push(key)
    res.push('_')
    res.push(obj[key] || '')
    res.push('__')
  }
  res.pop()
  return res.join('')
}

const decodeScene = str => {
  let res = {}
  let kvList = str.split('__')

  for (let kv of kvList) {
    let kvcdr = kv.split('_')
    if (kvcdr.length === 2) {
      res[kvcdr[0]] = kvcdr[1] || ''
    }
  }
  return res
}
```

## 使用

```
// 编码
let params =encodeScene({
      t: 'p',
      fuid: "5"
    })
wx.getImageInfo({
src: `${
          net.host
        }/100328/api/user/share/qrcode?page=${encodeURIComponent(
          'pages/system/login/index'
        )}&scene=${params}&width=120&uid=${userInfo.getToken()}`
})

// 解码

onLoad: function(options) {
    let scene = options.scene
    try {
      scene = util.decodeScene(scene)
      this.setData({
        target: scene.t || '',
        fromUserId: scene.fuid || '',
        id: scene.id || ''
      })
    } catch (e) {
      console.log(e)
    }
}
```
