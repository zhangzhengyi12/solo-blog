title: 利用 Github 的 Webhooks 能力自动构建发布博客
date: '2019-06-24 17:54:54'
updated: '2019-06-24 17:54:54'
tags: [blog, github, webhooks]
permalink: /articles/2019/06/24/1567739722748.html
---
直接放 github 成品地址

[code](git@github.com:zhangzhengyi12/blog-builder.git)

简单来说就是当github 仓库被提交的时候，github 就会访问你填写一个后台地址，你就可以通过这个触发器做一些事情。

为了避免麻烦我关闭了 screct 的验证，如果需要，在 blog.push 里面进行验证即可。

```conf
server{
    server_name your.site.name; # 换成你的域名
    listen 80;
    location / {
        # proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header Host $http_host;
        proxy_set_header X-NginX-Proxy true;
        proxy_pass http://127.0.0.1:9527$request_uri;
        proxy_redirect off;
    }
}
## https 设置 不需要可以忽略
server{
    server_name your.site.name; # 换成你的域名
    listen 443 ssl;
    ssl_certificate     /usr/local/nginx/conf/vhost.d/blog.auth/cer.crt;
    ssl_certificate_key /usr/local/nginx/conf/vhost.d/blog.auth/pri.key;
    location / {
        # proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header Host $http_host;
        proxy_set_header X-NginX-Proxy true;
        proxy_pass http://127.0.0.1:9527$request_uri;
        proxy_redirect off;
    }
}
```


完成之后访问 your.site.name 就是你的静态博客。 github webhooks 里面填写 your.site.name/push。会触发自动构建